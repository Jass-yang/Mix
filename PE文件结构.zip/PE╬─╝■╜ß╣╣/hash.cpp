#include <Windows.h>
#include <stdio.h>
#include"hash.h"

typedef struct _UNICODE_STRING {
	USHORT Length;
	USHORT MaximumLength;
	PWSTR  Buffer;
} UNICODE_STRING;

typedef struct _LDR_DATA_TABLE_ENTRY
{
	LIST_ENTRY InLoadOrderLinks;
	LIST_ENTRY InMemoryOrderLinks;
	LIST_ENTRY InInitializationOrderLinks;
	PVOID DllBase;
	PVOID EntryPoint;
	ULONG SizeOfImage;
	UNICODE_STRING FullDllName;
	UNICODE_STRING BaseDllName;
	ULONG Flags;
	USHORT LoadCount;
	USHORT TlsIndex;
	union {
		ULONG CheckSum;
		PVOID Reserved6;
	} DUMMYUNIONNAME;
	ULONG TimeDateStamp;
} LDR_DATA_TABLE_ENTRY, * PLDR_DATA_TABLE_ENTRY;

typedef struct _PEB_LDR_DATA {
	BYTE Reserved1[8];
	PVOID Reserved2[3];
	LIST_ENTRY InMemoryOrderModuleList;
} PEB_LDR_DATA, * PPEB_LDR_DATA;

typedef struct _PEB {
	BYTE Reserved1[2];
	BYTE BeingDebugged;
	BYTE Reserved2[1];
	PVOID Reserved3[2];
	PPEB_LDR_DATA Ldr;
	DWORD ProcessParameters;
	BYTE  Reserved4[104];
	PVOID Reserved5[52];
	DWORD PostProcessInitRoutine;
	BYTE  Reserved6[128];
	PVOID Reserved7[1];
	ULONG SessionId;
} PEB, * PPEB;

#define DEREF_64( name )*(DWORD64 *)(name)

#define MAXDLLNAME 64

constexpr int RandomSeed(void)
{
	return '0' * -40271 +
		__TIME__[7] * 1 +
		__TIME__[6] * 10 +
		__TIME__[4] * 60 +
		__TIME__[3] * 600 +
		__TIME__[1] * 3600 +
		__TIME__[0] * 36000;
};

constexpr auto SEED = RandomSeed() % 0xFF;


SIZE_T StringLengthA(LPCSTR String)
{
	LPCSTR String2;

	for (String2 = String; *String2; ++String2);

	return (String2 - String);
}

unsigned char LowerChar(unsigned char ch) {
	if (ch >= 'A' && ch <= 'Z')
		ch = 'a' + (ch - 'A');
	return ch;
}

UINT32 HashStringRotr32SubA(UINT32 Value, UINT Count)
{
	DWORD Mask = (CHAR_BIT * sizeof(Value) - 1);
	Count &= Mask;
#pragma warning( push )
#pragma warning( disable : 4146)
	return (Value >> Count) | (Value << ((-Count) & Mask));
#pragma warning( pop ) 
}

UINT32 HashStringRotr32A(PCHAR String)
{
	UINT32 Value = 0;

	for (INT Index = 0; Index < StringLengthA(String); Index++)
	{
		unsigned char lchar = LowerChar(String[Index]);
		Value = lchar + HashStringRotr32SubA(Value, SEED);
	}

	return Value;
}

#define HASHA(API) (HashStringRotr32A((PCHAR) API))
#define HASH(API) (HashStringRotr32A((PCHAR) #API))


UINT32 CopyDotStr(PCHAR String)
{
	for (UINT32 i = 0; i < StringLengthA(String); i++)
	{
		if (String[i] == '.')
			return i;
	}

	return 0;
}



PVOID RfCopyMemory(char* Destination, char* Source, SIZE_T Length)
{
	PBYTE D = (PBYTE)Destination;
	PBYTE S = (PBYTE)Source;

	while (Length--)
		*D++ = *S++;

	return Destination;
}


typedef HMODULE(WINAPI* fnLoadLibraryA)(LPCSTR lpLibFileName);
FARPROC GetProcAddressH(HMODULE hModule, UINT32 Hash);


HMODULE GetModuleHandleH(UINT32 ModuleHash) {
	if (ModuleHash == NULL)
		return NULL;
#ifdef _WIN64
	PPEB pPeb = (PPEB)__readgsqword(0x60);
#else
	PPEB pPeb = (PPEB)__readfsdword(0x30);
#endif

	PPEB_LDR_DATA pLdr = (PPEB_LDR_DATA)(pPeb->Ldr);
	PLDR_DATA_TABLE_ENTRY pDte = (PLDR_DATA_TABLE_ENTRY)(pLdr->InMemoryOrderModuleList.Flink);
	while (pDte) {
		if (pDte->FullDllName.Buffer != NULL) {
			if (pDte->FullDllName.Length < MAXDLLNAME - 1) {
				CHAR DllName[MAXDLLNAME] = { 0 };
				DWORD i = 0;
				while (pDte->FullDllName.Buffer[i] && i < sizeof(DllName) - 1) {
					DllName[i] = ((char)pDte->FullDllName.Buffer[i]);
					i++;
				}
				DllName[i] = '\0';
				if (HASHA(DllName) == ModuleHash) {
					return (HMODULE)(pDte->InInitializationOrderLinks.Flink);
				}
			}
		}
		else {
			break;
		}

		pDte = (PLDR_DATA_TABLE_ENTRY)DEREF_64(pDte);
	}
	return NULL;
}

HMODULE LoadLibraryH(LPCSTR ModuleName) {
	if (ModuleName == NULL) {
		return NULL;
	}

	fnLoadLibraryA pLoadLibraryA = (fnLoadLibraryA)GetProcAddressH(
		GetModuleHandleH(HASH(kernel32.dll)),
		HASH(LoadLibraryA)
	);

	if (pLoadLibraryA != NULL)
		return pLoadLibraryA(ModuleName);

	return NULL;
}

FARPROC GetProcAddressH(HMODULE hModule, UINT32 Hash) {

	if (hModule == NULL || Hash == NULL)
		return NULL;

	PBYTE pFunctionName;
	PIMAGE_DOS_HEADER DosHdr;
	PIMAGE_NT_HEADERS NtHdr;
	PIMAGE_FILE_HEADER FileHdr;
	PIMAGE_OPTIONAL_HEADER OptHdr;
	PIMAGE_EXPORT_DIRECTORY ExportTable;
	FARPROC ReturnAddress = NULL;

	DosHdr = (PIMAGE_DOS_HEADER)hModule;
	if (DosHdr->e_magic != IMAGE_DOS_SIGNATURE)
		return NULL;

	NtHdr = (PIMAGE_NT_HEADERS)((ULONG_PTR)DosHdr + DosHdr->e_lfanew);
	if (NtHdr->Signature != IMAGE_NT_SIGNATURE)
		return NULL;


	FileHdr = (PIMAGE_FILE_HEADER)((ULONG_PTR)hModule + DosHdr->e_lfanew + sizeof(DWORD));
	OptHdr = (PIMAGE_OPTIONAL_HEADER)((ULONG_PTR)FileHdr + sizeof(IMAGE_FILE_HEADER));
	ExportTable = (PIMAGE_EXPORT_DIRECTORY)((ULONG_PTR)hModule + OptHdr->DataDirectory[0].VirtualAddress);

	PDWORD FunctionNameAddressArray = (PDWORD)((ULONG_PTR)hModule + ExportTable->AddressOfNames);
	PDWORD FunctionAddressArray = (PDWORD)((ULONG_PTR)hModule + ExportTable->AddressOfFunctions);
	PWORD FunctionOrdinalAddressArray = (PWORD)((ULONG_PTR)hModule + ExportTable->AddressOfNameOrdinals);


	for (DWORD i = 0; i < ExportTable->NumberOfNames; i++) {
		pFunctionName = (PBYTE)(FunctionNameAddressArray[i] + (ULONG_PTR)hModule);
		if (Hash == HASHA(pFunctionName)) {
			ReturnAddress = (FARPROC)((ULONG_PTR)hModule + FunctionAddressArray[FunctionOrdinalAddressArray[i]]);
			if ((ULONG_PTR)ReturnAddress >= (ULONG_PTR)ExportTable &&
				(ULONG_PTR)ReturnAddress < (ULONG_PTR)(ExportTable + (ULONG_PTR)hModule + NtHdr->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].Size)) {

				CHAR Library[MAX_PATH] = { 0 };
				CHAR Function[MAX_PATH] = { 0 };
				UINT32 Index = CopyDotStr((PCHAR)ReturnAddress);
				RfCopyMemory((char*)Library, (char*)ReturnAddress, Index);
				RfCopyMemory((char*)Function, (char*)((ULONG_PTR)ReturnAddress + Index + 1), StringLengthA((LPCSTR)((ULONG_PTR)ReturnAddress + Index + 1)));
				if ((hModule = LoadLibraryH(Library)) != NULL) {
					ReturnAddress = GetProcAddressH(hModule, HASHA(Function));
				}
			}
			return ReturnAddress;
		}
	}

	return NULL;
}


