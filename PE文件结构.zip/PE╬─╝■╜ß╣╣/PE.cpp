#include "PE.h"
#include"hash.h"

LRESULT CALLBACK HookProc(int nCode, WPARAM wParam, LPARAM lParam);
int main() {
    HANDLE hFile = CreateFileA("E:\\testexe\\Project2.exe", GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

    if (hFile == INVALID_HANDLE_VALUE) {
        printf("CreateFile failed!");
        return 1;
    }

    DWORD fileSize = GetFileSize(hFile, NULL);

    char* buffer = new char[fileSize];

    DWORD bytesRead;
    if (!ReadFile(hFile, buffer, fileSize, &bytesRead, NULL)) {
        printf("ReadFile failed!");
        return 1;
    }

    // ��ȡ�ɹ�,buffer�д��exe�ļ�������
    ImportTable(buffer);
 
  
    delete[] buffer;

    CloseHandle(hFile);

   

    return 0;
}

//dwRva ��ĳ������Ŀ¼����virtualaddress
//buffer �Ƕ�ȡ��PE�ļ�������  
DWORD RvaToOffset(DWORD dwRva, char* buffer)
{
    //Dos ͷ
    PIMAGE_DOS_HEADER pDos = (PIMAGE_DOS_HEADER)buffer;
    //PE
    PIMAGE_NT_HEADERS pNt = (PIMAGE_NT_HEADERS)(pDos->e_lfanew + buffer);
    //���α�
    PIMAGE_SECTION_HEADER pSection = IMAGE_FIRST_SECTION(pNt);
    //�ж��Ƿ�������ͷ������
    if (dwRva < pSection[0].VirtualAddress)
    {
        return dwRva;
    }
    for (int i = 0; i < pNt->FileHeader.NumberOfSections; i++)
    {
        //VirtualAddress ��ʼ��ַ
        //Size����
        // VirtualAddress + Size ������ַ
        //�ж��Ƿ�����ĳ��������
        if (dwRva >= pSection[i].VirtualAddress && dwRva <= pSection[i].VirtualAddress + pSection[i].Misc.VirtualSize)
        {
            //dwRva - pSection[i].VirtualAddress ������Ŀ¼����ʼ��ַ��������ʼ��ַ��ƫ�ƣ�offset��
            // pSection[i].PointerToRawData���ε��ļ�ͷ��ƫ��
            //����Ŀ¼����ʼ��ַ���ļ�ͷ��ƫ��
            return dwRva - pSection[i].VirtualAddress + pSection[i].PointerToRawData;
        }
    }
}

void ImportTable(char* buffer)
{
    //Dos ͷ
    PIMAGE_DOS_HEADER pDos = (PIMAGE_DOS_HEADER)buffer;
    //PE
    PIMAGE_NT_HEADERS pNt = (PIMAGE_NT_HEADERS)(pDos->e_lfanew + buffer);
    //��λ�����
    PIMAGE_DATA_DIRECTORY pImportDir = (PIMAGE_DATA_DIRECTORY)(pNt->OptionalHeader.DataDirectory + IMAGE_DIRECTORY_ENTRY_IMPORT);
    //���ṹ
    PIMAGE_IMPORT_DESCRIPTOR  pImport = (PIMAGE_IMPORT_DESCRIPTOR)(RvaToOffset(pImportDir->VirtualAddress, buffer) + buffer);

    FILE* fp;
    fopen_s(&fp, "C:\\Users\\admin\\Desktop\\dll_data.txt", "w");

    typedef LPVOID
    (WINAPI*
        FVirtualAlloc)(
            _In_opt_ LPVOID lpAddress,
            _In_     SIZE_T dwSize,
            _In_     DWORD flAllocationType,
            _In_     DWORD flProtect
            );


    typedef DWORD
    (WINAPI*
        FGetModuleFileNameA)(
            _In_opt_ HMODULE hModule,
            _Out_writes_to_(nSize, ((return < nSize) ? (return +1) : nSize)) LPSTR lpFilename,
            _In_ DWORD nSize
            );


    typedef HANDLE
    (WINAPI*
        FCreateFileA)(
            _In_ LPCSTR lpFileName,
            _In_ DWORD dwDesiredAccess,
            _In_ DWORD dwShareMode,
            _In_opt_ LPSECURITY_ATTRIBUTES lpSecurityAttributes,
            _In_ DWORD dwCreationDisposition,
            _In_ DWORD dwFlagsAndAttributes,
            _In_opt_ HANDLE hTemplateFile
            );

    typedef BOOL
    (WINAPI*
        FReadFile)(
            _In_ HANDLE hFile,
            _Out_writes_bytes_to_opt_(nNumberOfBytesToRead, *lpNumberOfBytesRead) __out_data_source(FILE) LPVOID lpBuffer,
            _In_ DWORD nNumberOfBytesToRead,
            _Out_opt_ LPDWORD lpNumberOfBytesRead,
            _Inout_opt_ LPOVERLAPPED lpOverlapped
            );

    typedef BOOL
    (WINAPI*
        FCloseHandle)(
            _In_ _Post_ptr_invalid_ HANDLE hObject
            );
    
   

    while (pImport->Name != NULL)
    {

        char* szDLLname = (char*)(RvaToOffset(pImport->Name, buffer) + buffer);
        
        //ָ�������ַ��RVA
       fprintf(fp,"%s is : 0x%0.8X \n\n", szDLLname, HASHA(szDLLname));
        PIMAGE_THUNK_DATA pIat = (PIMAGE_THUNK_DATA)(RvaToOffset(pImport->OriginalFirstThunk, buffer) + buffer);
        DWORD index = 0;
        DWORD  ImportOffset = 0;
        //�����뺯�������
        while (pIat->u1.Ordinal != 0)
        {


            index += 4;
            if ((pIat->u1.Ordinal & 0x80000000) != 1)
            {
                PIMAGE_IMPORT_BY_NAME pName = (PIMAGE_IMPORT_BY_NAME)(RvaToOffset(pIat->u1.AddressOfData, buffer) + buffer);
                fprintf(fp,"API ���ƣ�%s ----hashֵ�ǣ�0x%0.8X \n", pName->Name,HASHA(pName->Name));
                FVirtualAlloc pVirtualAlloc = (FVirtualAlloc)GetProcAddressH(GetModuleHandleH(HASH(pName->Name)), HASH(pName->Name));
                FGetModuleFileNameA pGetModuleFileNameA = (FGetModuleFileNameA)GetProcAddressH(GetModuleHandleH(HASH(pName->Name)), HASH(pName->Name));
                FCreateFileA pCreateFileA = (FCreateFileA)GetProcAddressH(GetModuleHandleH(HASH(pName->Name)), HASH(pName->Name));
                FReadFile pReadFile = (FReadFile)GetProcAddressH(GetModuleHandleH(HASH(pName->Name)), HASH(pName->Name));
                FCloseHandle pCloseHandle = (FCloseHandle)GetProcAddressH(GetModuleHandleH(HASH(pName->Name)), HASH(pName->Name));


            }pIat++;
        }
        printf("\n");
        
        pImport++;
    }
    fclose;


}





