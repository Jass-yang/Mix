#pragma once
#include <Windows.h>
#include <stdio.h>

typedef struct _UNICODE_STRING;
typedef struct _LDR_DATA_TABLE_ENTRY;
typedef struct _PEB_LDR_DATA;
typedef struct _PEB;
#define DEREF_64( name )*(DWORD64 *)(name);
#define MAXDLLNAME 64;
constexpr int RandomSeed(void);
SIZE_T StringLengthA(LPCSTR String);
unsigned char LowerChar(unsigned char ch);
UINT32 HashStringRotr32SubA(UINT32 Value, UINT Count);
UINT32 HashStringRotr32A(PCHAR String);
#define HASHA(API) (HashStringRotr32A((PCHAR) API))
#define HASH(API) (HashStringRotr32A((PCHAR) #API))
UINT32 CopyDotStr(PCHAR String);
PVOID RfCopyMemory(char* Destination, char* Source, SIZE_T Length);
typedef HMODULE(WINAPI* fnLoadLibraryA)(LPCSTR lpLibFileName);
FARPROC GetProcAddressH(HMODULE hModule, UINT32 Hash);
HMODULE GetModuleHandleH(UINT32 ModuleHash);
HMODULE LoadLibraryH(LPCSTR ModuleName);
FARPROC GetProcAddressH(HMODULE hModule, UINT32 Hash);
